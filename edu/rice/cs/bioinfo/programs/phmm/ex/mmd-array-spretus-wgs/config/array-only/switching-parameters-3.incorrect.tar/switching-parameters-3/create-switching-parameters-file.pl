#!/usr/bin/env perl


my %choices = 
    (
     "deltaf" => "p1,p1",
     "deltat" => "p2,p2"
    );
foreach my $key (keys(%choices)) {
    print "$key 0.0001";
    my @pa = split(",", $choices{$key});
    for (my $i = 1; $i <= 15; $i++) {
	for (my $j = 1; $j <= 15; $j++) {
	    if ($i != $j) {
		my $si = $i;
		my $sj = $j;
		if ($i < 10) {
		    $si = "0" . $si;
		}
		if ($sj < 10) {
		    $sj = "0" . $sj;
		}
		print " $pa[0],g$si|$pa[1],g$sj";
	    }
	}
    }
    print "\n";
}

print "gamma 0.0001";
for (my $x = 1; $x <= 2; $x++) {
    for (my $y = 1; $y <= 2; $y++) {
	if ($x == $y) {
	    next;
	}

	for (my $i = 1; $i <= 15; $i++) {
	    for (my $j = 1; $j <= 15; $j++) {
		my $si = $i;
		my $sj = $j;
		if ($i < 10) {
		    $si = "0" . $si;
		}
		if ($sj < 10) {
		    $sj = "0" . $sj;
		}
		print " p$x,g$si|p$y,g$sj";
	    }
	}
    }
}
print "\n";

